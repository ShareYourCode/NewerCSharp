﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;

namespace CSharpSevenPointThreeFeatures
{
    /// <summary>
    /// 扩展初始值设定项中的表达式变量：成员初始值设定项和查询中的表达式变量声明
    /// </summary>
    public static class ExtendExpressionVariablesInInitializers
    {
        public static void ExtendExpressionVariablesInInitializersDemoOne()
        {
            int first = 5;
            D d = new D(first);
            E e = new E(first);
            F f = new F(first);
        }
    }

    public class B
    {
        public B(int i, out int j)
        {
            j = i;
        }
    }

    public class D : B
    {
        private static int j = 8;
        public D(int i) : base(i, out j) // C# 7.3 前不能在此定义变量，只能传入参数
        {
            WriteLine($"The value of 'j' is {j}");
        }
    }

    public class E : B
    {
        public E(int i) : base(i, out int k) // C# 7.3 后支持“成员初始值设定项和查询中的表达式变量声明”语法
        {
            WriteLine($"The value of 'k' is {k}");
        }
    }

    public class F : B
    {
        public F(int i) : base(i, out var t) // C# 7.3 后支持“成员初始值设定项和查询中的表达式变量声明”语法
        {
            WriteLine($"The value of 't' is {t}");
        }
    }
}
