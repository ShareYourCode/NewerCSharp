﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;

namespace CSharpSevenPointThreeFeatures
{
    /// <summary>
    /// 索引 fixed 字段不需要进行固定
    /// </summary>
    public static class IndexingFixedFieldsDoesNotRequirePinning
    {
        public static void IndexingFixedFieldsDoesNotRequirePinningDemoOne()
        {
            C c = new C();
            c.M();
        }
    }

    public unsafe struct S
    {
        public fixed int myFixedField[10];
    }

    public class C
    {
        static S s = new S();

        unsafe public void M()
        {
            // C# 7.3 之前
            fixed (int* ptr = s.myFixedField)
            {
                int pt = ptr[5];
                WriteLine(pt);
            }

            // C# 7.3 之后
            int pr = s.myFixedField[5];
            WriteLine(pr);
        }
    }
}
