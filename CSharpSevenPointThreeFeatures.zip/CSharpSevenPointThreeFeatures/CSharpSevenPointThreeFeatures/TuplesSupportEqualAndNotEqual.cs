﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;

namespace CSharpSevenPointThreeFeatures
{
    /// <summary>
    /// 元组类型现在支持 == 和 !=
    /// 这些运算符按顺序将左边参数的每个成员与右边参数的每个成员进行比较
    /// 这些比较将发生短路，只要有一对不相等，它们即会停止计算成员
    /// 元组成员名称不参与相等测试
    /// 元组可能包含嵌套元组，元组相等通过嵌套元组比较每个操作数的“形状”
    /// </summary>
    public static class TuplesSupportEqualAndNotEqual
    {
        public static void TuplesSupportEqualAndNotEqualDemoOne()
        {
            var left = (a: 5, b: 10);
            var right = (a: 5, b: 10);
            WriteLine(left == right); // displays 'true'
            WriteLine(left != right);

            var up = (c: 5, d: 10);
            var bottom = (k: 5, p: 10);
            WriteLine(up == bottom); // displays 'true'
            WriteLine(up != bottom);
        }

        public static void TuplesSupportEqualAndNotEqualDemoTwo()
        {
            var left = (a: 5, b: 10);
            var right = (a: 5, b: 10);
            (int a, int b)? nullableTuple = right;
            WriteLine(left == nullableTuple); // Also true
            WriteLine(left != nullableTuple);

            WriteLine(right == nullableTuple);
            WriteLine(right != nullableTuple);
        }

        public static void TuplesSupportEqualAndNotEqualDemoThree()
        {
            // lifted conversions
            var left = (a: 5, b: 10);
            (int? a, int? b) nullableMembers = (5, 10);
            WriteLine(left == nullableMembers); // Also true

            // converted type of left is (long, long)
            (long a, long b) longTuple = (5, 10);
            WriteLine(left == longTuple); // Also true

            // comparisons performed on (long, long) tuples
            (long a, int b) longFirst = (5, 10);
            (int a, long b) longSecond = (5, 10);
            WriteLine(longFirst == longSecond); // Also true
            WriteLine(left == longFirst); // Also true
            WriteLine(left == longSecond); // Also true
        }

        /// <summary>
        /// 元组成员名称不参与相等测试
        /// 但是，如果其中一个操作数是含有显式名称的元组文本，则当这些名称与其他操作数的名称不匹配时，编译器将生成警告 CS8383
        /// 在两个操作数都为元组文本的情况下，警告位于右侧操作数
        /// </summary>
        public static void TuplesSupportEqualAndNotEqualDemoFour()
        {
            (int a, string b) pair = (1, "Hello");
            (int z, string y) another = (1, "Hello");
            WriteLine(pair == another); // true. Member names don't participate.
            WriteLine(pair == (z: 1, y: "Hello")); // warning: literal contains different member names
        }

        public static void TuplesSupportEqualAndNotEqualDemoFive()
        {
            (int, (int, int)) nestedTuple = (1, (2, 3));
            WriteLine(nestedTuple == (1, (2, 3)));
            WriteLine(nestedTuple == (1, (3, 2)));
        }
    }
}
