﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;
using static CSharpSevenPointThreeFeatures.IndexingFixedFieldsDoesNotRequirePinning;
using static CSharpSevenPointThreeFeatures.RefLocalVariablesMayBeReassigned;
using static CSharpSevenPointThreeFeatures.StackallocArraysSupportInitializers;
using static CSharpSevenPointThreeFeatures.MoreTypesSupportTheFixedStatement;
using static CSharpSevenPointThreeFeatures.TuplesSupportEqualAndNotEqual;
using static CSharpSevenPointThreeFeatures.ExtendExpressionVariablesInInitializers;

namespace CSharpSevenPointThreeFeatures
{
    class Program
    {
        static void Main(string[] args)
        {
            IndexingFixedFieldsDoesNotRequirePinningDemoOne();

            RefLocalVariablesMayBeReassignedDemoOne();

            StackallocArraysSupportInitializersDemoOne();

            MoreTypesSupportTheFixedStatementDemoOne();

            EnhancedGenericConstraints enhancedGenericConstraints = new EnhancedGenericConstraints();
            enhancedGenericConstraints.EnhancedGenericConstraintsDemoOne();

            TuplesSupportEqualAndNotEqualDemoOne();

            TuplesSupportEqualAndNotEqualDemoTwo();

            TuplesSupportEqualAndNotEqualDemoThree();

            TuplesSupportEqualAndNotEqualDemoFour();

            TuplesSupportEqualAndNotEqualDemoFive();

            ExtendExpressionVariablesInInitializersDemoOne();

            ReadLine();
        }
    }
}
