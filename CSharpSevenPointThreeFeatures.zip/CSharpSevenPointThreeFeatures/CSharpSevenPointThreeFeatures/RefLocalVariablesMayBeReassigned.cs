﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;

namespace CSharpSevenPointThreeFeatures
{
    /// <summary>
    /// 可能会重新分配 ref 局部变量：在对 ref 局部变量进行初始化后，可能会对其重新分配，以引用不同的实例
    /// </summary>
    public static class RefLocalVariablesMayBeReassigned
    {
        public static void RefLocalVariablesMayBeReassignedDemoOne()
        {
            VeryLargeStruct veryLargeStruct = new VeryLargeStruct(4, 8);
            VeryLargeStruct anotherVeryLargeStruct = new VeryLargeStruct(7, 12);

            WriteLine($"({veryLargeStruct.X}, {veryLargeStruct.Y})");
            ref VeryLargeStruct refLocal = ref veryLargeStruct; // initialization
            WriteLine($"({refLocal.X}, {refLocal.Y})");
            // C# 7.3 后才支持 ref 赋值（但上一句定义 ref 变量（“ref 局部变量和返回”）在 C# 7.0 后就支持了）
            refLocal = ref anotherVeryLargeStruct; // reassigned, refLocal refers to different storage.
            WriteLine($"({refLocal.X}, {refLocal.Y})");
        }
    }

    public struct VeryLargeStruct
    {
        public int X;
        public int Y;

        public VeryLargeStruct(int x, int y)
        {
            X = x;
            Y = y;
        }
    }
}
