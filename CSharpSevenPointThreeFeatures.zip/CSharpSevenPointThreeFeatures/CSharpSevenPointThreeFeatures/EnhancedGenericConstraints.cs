﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;

namespace CSharpSevenPointThreeFeatures
{
    /// <summary>
    /// 增强的泛型约束：C# 7.3 后可以将类型 System.Enum 或 System.Delegate 指定为类型参数的基类约束
    /// </summary>
    public class EnhancedGenericConstraints
    {
        public delegate string AddDelete(int a, int b);

        public delegate int MinusDelete(int a, int b);

        public void EnhancedGenericConstraintsDemoOne()
        {
            CustomColor customColor = CustomColor.Orange;
            EnhancedGenericConstraintsDemoOne<CustomColor>(customColor);
            EnhancedGenericConstraintsDemoTwo<AddDelete>(TestAddDelete);
            customColor = CustomColor.Red;
            EnhancedGenericConstraintsDemoThree<CustomColor, AddDelete>(customColor);
            EnhancedGenericConstraintsDemoFour<CustomColor, AddDelete>(TestAddDelete);
            customColor = CustomColor.Yellow;
            EnhancedGenericConstraintsDemoFive<CustomColor, MinusDelete>(customColor, TestMinusDelete);
        }

        private string TestAddDelete(int a, int b)
        {
            int c = a + b;
            return c.ToString();
        }

        private static int TestMinusDelete(int a, int b)
        {
            int c = a - b;
            return c;
        }

        private void EnhancedGenericConstraintsDemoOne<T>(T packet) where T : Enum
        {
            WriteLine(packet);
        }

        private void EnhancedGenericConstraintsDemoTwo<U>(U donkey) where U : Delegate
        {
            WriteLine(donkey);
            object res = donkey.DynamicInvoke(5, 8);
            WriteLine(res);
        }

        private void EnhancedGenericConstraintsDemoThree<T, U>(T packet) where T : Enum where U : Delegate
        {
            WriteLine(packet);
        }

        private void EnhancedGenericConstraintsDemoFour<T, U>(U donkey) where T : Enum where U : Delegate
        {
            WriteLine(donkey);
            object res = donkey.Method.Invoke(this, new object[] { 6, 9 });
            WriteLine(res);
        }

        private void EnhancedGenericConstraintsDemoFive<T, U>(T packet, U donkey) where T : Enum where U : Delegate
        {
            WriteLine(packet);
            WriteLine(donkey);
            object res = donkey.Method.Invoke(null, new object[] { 15, 6 });
            WriteLine(res);
        }
    }

    public enum CustomColor
    {
        Red,
        Green,
        Blue,
        Yellow,
        Orange
    }
}
