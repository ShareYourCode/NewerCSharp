﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;

namespace CSharpSevenPointThreeFeatures
{
    /// <summary>
    /// 从 C# 7.3 开始，任何包含返回 ref T 或 ref readonly T 的 GetPinnableReference() 方法的类型均有可能为 fixed 
    /// 这意味着 fixed 可与 System.Span<T> 和相关类型配合使用
    /// </summary>
    public static class MoreTypesSupportTheFixedStatement
    {
        public static void MoreTypesSupportTheFixedStatementDemoOne()
        {
            FSE fse = new FSE();
            fse.FixedSpanExample();
        }
    }

    public class FSE
    {
        unsafe public void FixedSpanExample()
        {
            int[] PascalsTriangle = {
                          1,
                        1,  1,
                      1,  2,  1,
                    1,  3,  3,  1,
                  1,  4,  6,  4,  1,
                1,  5,  10, 10, 5,  1
            };

            Span<int> RowFive = new Span<int>(PascalsTriangle, 10, 5);

            fixed (int* ptrToRow = RowFive)
            {
                // Sum the numbers 1,4,6,4,1
                var sum = 0;
                for (int i = 0; i < RowFive.Length; i++)
                {
                    sum += *(ptrToRow + i);
                }
                WriteLine(sum);
            }
        }
    }
}
