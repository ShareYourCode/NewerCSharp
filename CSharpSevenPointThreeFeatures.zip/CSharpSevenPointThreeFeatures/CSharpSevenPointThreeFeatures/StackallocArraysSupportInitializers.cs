﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;

namespace CSharpSevenPointThreeFeatures
{
    /// <summary>
    /// stackalloc 数组支持初始值设定项
    /// </summary>
    public static class StackallocArraysSupportInitializers
    {
        public static void StackallocArraysSupportInitializersDemoOne()
        {
            STK stk = new STK();
            stk.M();
        }
    }

    public class STK
    {
        unsafe public void M()
        {
            var arr1 = new int[3] { 1, 2, 3 };
            var arr2 = new int[] { 1, 2, 3 };

            int* pArr1 = stackalloc int[3] { 1, 2, 3 }; // C# 7.3 之后 stackalloc 数组支持初始值设定项
            int* pArr2 = stackalloc int[] { 1, 2, 3 }; // C# 7.3 之后 stackalloc 数组支持初始值设定项
            int* pArr = stackalloc int[3]; // C# 7.3 前 stackalloc 数组定义时不能同时初始化

            WriteLine(string.Join(",", arr1));
            WriteLine(string.Join(",", arr2));

            WriteLine(pArr1[0]);
            WriteLine(pArr1[1]);
            WriteLine(pArr1[2]);
            WriteLine(pArr2[0]);
            WriteLine(pArr2[1]);
            WriteLine(pArr2[2]);

            WriteLine(pArr[0]);
            WriteLine(pArr[1]);
            WriteLine(pArr[2]);
        }
    }
}
