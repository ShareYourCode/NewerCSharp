﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;
using static CSharpSevenPointTwoFeatures.TechniquesForWritingSafeEfficientCode;
using static CSharpSevenPointTwoFeatures.NonTrailingNamedArguments;
using static CSharpSevenPointTwoFeatures.LeadingUnderscoresInNumericLiterals;
using static CSharpSevenPointTwoFeatures.ConditionalRefExpressions;
using static CSharpSevenPointTwoFeatures.InMethodOverloadResolutionTieBreaker;

namespace CSharpSevenPointTwoFeatures
{
    class Program
    {
        static void Main(string[] args)
        {
            TechniquesForWritingSafeEfficientCodeDemoOne();

            NonTrailingNamedArgumentsDemoOne();

            LeadingUnderscoresInNumericLiteralsDemoOne();

            PrivateProtectedAccessModifier privateProtectedAccessModifier = new PrivateProtectedAccessModifier();
            privateProtectedAccessModifier.PrivateProtectedAccessModifierDemoOne();

            ConditionalRefExpressionsDemoOne();

            InMethodOverloadResolutionTieBreakerDemoOne();

            ReadLine();
        }
    }
}
