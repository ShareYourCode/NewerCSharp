﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;

namespace CSharpSevenPointTwoFeatures
{
    /// <summary>
    /// 安全高效的代码的增强功能：
    /// 1）readonly struct：指示结构不可变，且应作为 in 参数传递到其成员方法
    /// 2）ref struct：指示结构类型直接访问托管的内存，且必须始终分配有堆栈，ref struct 不能实现接口，也不能是类的成员，也不能用于可能在堆上分配的其他位置
    /// </summary>
    public static class TechniquesForWritingSafeEfficientCode
    {
        public static void TechniquesForWritingSafeEfficientCodeDemoOne()
        {
            ReadonlyPoint3D point = new ReadonlyPoint3D(1, 2, 3, 15, 9);
            string result = point.M(88, 72);
            WriteLine(result);
        }
    }

    public interface IA
    {
        string M(int a, int b);
    }

    /// <summary>
    /// C# 7.2 之前不支持 readonly 结构体：使用 readonly 修饰符声明 struct 将通知编译器你的意图是创建不可变类型
    /// readonly struct 中所有字段必须为 readonly，且所有属性都必须是只读的包括自动实现的属性，这两个规则足以确保 readonly struct 的任何成员都不会修改该结构的状态
    /// 结构中不能实例属性或字段初始值选定项
    /// </summary>
    readonly public struct ReadonlyPoint3D : IA
    {
        public ReadonlyPoint3D(double x, double y, double z, double width, double height)
        {
            this.X = x;
            this.Y = y;
            this.Z = z;
            this.Width = width;
            this.Height = height;
        }

        public double X { get; }
        public double Y { get; }
        public double Z { get; }

        readonly public double Width;
        readonly public double Height;

        public string M(int a, int b)
        {
            double c = a + b + X + Y;
            return c.ToString();
        }
    }

    public ref struct RefPoint3D { }
    //! public ref struct RefPoint3D : IA { }

    readonly public ref struct ReadonlyRefPoint3D { }
    //! readonly public ref struct ReadonlyRefPoint3D: IA { }
}
