﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;

namespace CSharpSevenPointTwoFeatures
{
    /// <summary>
    /// 条件 ref 表达式：条件表达式可以生成 ref 结果而不是值
    /// </summary>
    public static class ConditionalRefExpressions
    {
        public static void ConditionalRefExpressionsDemoOne()
        {
            var arr = new int[5] { 6, 7, 18, 99, 108 };
            var otherArr = new int[3] { 7, 44, 32 };
            ref var r = ref (arr != null ? ref arr[0] : ref otherArr[0]);
            WriteLine(r);
            r = 1024;
            WriteLine(string.Join(",", arr));
            WriteLine(string.Join(",", otherArr));
            arr = null;
            ref int t = ref (arr != null ? ref arr[0] : ref otherArr[0]);
            WriteLine(t);
            t = 9999;
            WriteLine(string.Join(",", otherArr));
        }
    }
}
