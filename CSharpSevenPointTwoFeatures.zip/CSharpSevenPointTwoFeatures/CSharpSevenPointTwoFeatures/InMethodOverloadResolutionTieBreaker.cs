﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;

namespace CSharpSevenPointTwoFeatures
{
    /// <summary>
    /// in 方法重载解析决胜属性
    /// </summary>
    public static class InMethodOverloadResolutionTieBreaker
    {
        public static void InMethodOverloadResolutionTieBreakerDemoOne()
        {
            ODR odr = new ODR();
            M(odr);
            M(in odr);
        }

        private static void M(ODR arg)
        {
            WriteLine(arg);
        }
        private static void M(in ODR arg)
        {
            WriteLine($"Inner: {arg}");
        }
    }

    public class ODR { }
}
