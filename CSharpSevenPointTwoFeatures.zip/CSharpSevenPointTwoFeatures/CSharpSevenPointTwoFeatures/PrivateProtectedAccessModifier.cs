﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;

namespace CSharpSevenPointTwoFeatures
{
    /// <summary>
    /// private protected 访问修饰符
    /// 命名空间中定义的元素无法显式声明为 private、protected、protected internal 或 private protected
    /// private protected 指示可通过包含同一程序集中声明的类或派生类来访问成员
    /// 虽然 protected internal 允许通过同一程序集中的类或派生类进行访问，但 private protected 限制对同一程序集中声明的派生类的访问
    /// </summary>
    public class PrivateProtectedAccessModifier
    {
        private protected int myValue = 5;

        public void PrivateProtectedAccessModifierDemoOne()
        {
            WriteLine(myValue);
            InnerClass ic = new InnerClass();
            WriteLine(ic.ShowPrivateProtectedField());
        }

        private protected class InnerClass
        {
            private protected int yourValue = 2;

            public int ShowPrivateProtectedField()
            {
                return yourValue;
            }
        }
    }
}
