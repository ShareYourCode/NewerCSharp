﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;

namespace CSharpSevenPointTwoFeatures
{
    /// <summary>
    /// 非尾随命名参数
    /// </summary>
    public static class NonTrailingNamedArguments
    {
        public static void NonTrailingNamedArgumentsDemoOne()
        {
            WriteLine(Volume(3, 4, 5));

            WriteLine(Volume(a: 3, 4, 5));  // C# 7.2 之前，命名参数规范必须出现在所有固定参数都已指定完毕后
            WriteLine(Volume(3, b: 4, 5));  // C# 7.2 之前，命名参数规范必须出现在所有固定参数都已指定完毕后
            WriteLine(Volume(3, 4, c: 5));

            WriteLine(Volume(a: 3, b: 4, 5));  // C# 7.2 之前，命名参数规范必须出现在所有固定参数都已指定完毕后
            WriteLine(Volume(a: 3, 4, c: 5));  // C# 7.2 之前，命名参数规范必须出现在所有固定参数都已指定完毕后
            WriteLine(Volume(3, b: 4, c: 5));

            WriteLine(Volume(a: 3, c: 5, b: 4));

            //! Volume(3, c:4, 5); // 错误，因为指定了参数 c 的值两次
        }

        private static int Volume(int a, int b, int c)
        {
            return a * b * c;
        }
    }
}
