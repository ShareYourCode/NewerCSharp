﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;

namespace CSharpSevenPointOneFeatures
{
    /// <summary>
    /// 默认文本表达式
    /// 默认文本表达式是针对默认值表达式的一项增强功能，这些表达式将变量初始化为默认值
    /// </summary>
    public static class DefaultLiteralExpressions
    {
        public static void DefaultLiteralExpressionsDemoOne()
        {
            Func<string, bool> oldWhereClause = default(Func<string, bool>); // 以往的写法
            Func<string, bool> newWhereClause = default; // 新写法
            if (oldWhereClause == null)
            {
                WriteLine("whereClause is null");
            }
            if (newWhereClause == null)
            {
                WriteLine("whereClause is null");
            }
        }
    }
}
