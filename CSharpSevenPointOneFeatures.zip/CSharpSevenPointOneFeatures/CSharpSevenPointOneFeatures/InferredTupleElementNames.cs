﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;

namespace CSharpSevenPointOneFeatures
{
    /// <summary>
    /// 推断元组元素名称
    /// 定义元组时不提供元组元素的名称，那么元组元素的名称将对应设置为变量的名称（C# 7.1 才开始支持这种语法），如果是直接给出字面值，那么元组元素的名称会回归为 ItemN
    /// 在 C# 7.1 之前，这种情况下，元组元素的名称会是 ItemN
    /// </summary>
    public static class InferredTupleElementNames
    {
        public static void InferredTupleElementNamesDemoOne()
        {
            int count = 5;
            string label = "Colors used in the map";
            var pair1 = (count: count, label: label);
            var pair2 = (cnt: count, bel: label);
            var pair3 = (count, label); // element names are "count" and "label"
            var pair4 = (7, label);
            var pair5 = (9, "label");

            WriteLine($"Count: {pair1.Item1}, Label: {pair1.Item2}");
            WriteLine($"Count: {pair1.count}, Label: {pair1.label}");

            WriteLine($"Count: {pair2.Item1}, Label: {pair2.Item2}");
            WriteLine($"Count: {pair2.cnt}, Label: {pair2.bel}");

            WriteLine($"Count: {pair3.Item1}, Label: {pair3.Item2}");
            WriteLine($"Count: {pair3.count}, Label: {pair3.label}");

            WriteLine($"Count: {pair4.Item1}, Label: {pair4.Item2}");
            WriteLine($"Count: {pair4.Item1}, Label: {pair4.label}");

            WriteLine($"Count: {pair5.Item1}, Label: {pair5.Item2}");
        }
    }
}
