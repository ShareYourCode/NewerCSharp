﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace CSharpSevenPointOneFeatures
{
    /// <summary>
    /// 异步 Main 方法使你能够在 Main 方法中使用 await 关键字
    /// 而在以前的版本，需要编写：异步方法名([参数列表]).GetAwaiter().GetResult()
    /// </summary>
    public static class AsyncMain
    {
        async public static Task AsyncMainDemoOne()
        {
            HttpClient client = new HttpClient();
            string reqUrl = "https://gss0.baidu.com/-4o3dSag_xI4khGko9WTAnF6hhy/zhidao/pic/item/6609c93d70cf3bc7632b3aafd300baa1cd112a4e.jpg";
            HttpResponseMessage responseMessage = await client.GetAsync(reqUrl);
            string result = await responseMessage.Content.ReadAsStringAsync();
        }

        async public static Task<int> AsyncMainDemoTwo()
        {
            HttpClient client = new HttpClient();
            string reqUrl = "https://gss0.baidu.com/-4o3dSag_xI4khGko9WTAnF6hhy/zhidao/pic/item/6609c93d70cf3bc7632b3aafd300baa1cd112a4e.jpg";
            HttpResponseMessage responseMessage = await client.GetAsync(reqUrl);
            string result = await responseMessage.Content.ReadAsStringAsync();
            int resultLength = result.Length;
            return resultLength;
        }

        async public static Task<string> AsyncMainDemoThree()
        {
            HttpClient client = new HttpClient();
            string reqUrl = "https://gss0.baidu.com/-4o3dSag_xI4khGko9WTAnF6hhy/zhidao/pic/item/6609c93d70cf3bc7632b3aafd300baa1cd112a4e.jpg";
            HttpResponseMessage responseMessage = await client.GetAsync(reqUrl);
            string result = await responseMessage.Content.ReadAsStringAsync();
            return result;
        }
    }
}
