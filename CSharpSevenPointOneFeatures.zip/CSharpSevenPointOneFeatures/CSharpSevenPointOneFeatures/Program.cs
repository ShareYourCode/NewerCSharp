﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;
using static CSharpSevenPointOneFeatures.AsyncMain;
using static CSharpSevenPointOneFeatures.DefaultLiteralExpressions;
using static CSharpSevenPointOneFeatures.InferredTupleElementNames;
using static CSharpSevenPointOneFeatures.PatternMatchingOnGenericTypeParameters;

namespace CSharpSevenPointOneFeatures
{
    class Program
    {
        /// <summary>
        /// 也可以写成 Task<int>
        /// </summary>
        /// <param name="args"></param>
        /// <returns></returns>
        async static Task Main(string[] args)
        {
            AsyncMainDemoOne().GetAwaiter().GetResult();
            int x1 = AsyncMainDemoTwo().GetAwaiter().GetResult();
            string x2 = AsyncMainDemoThree().GetAwaiter().GetResult();

            await AsyncMainDemoOne();
            int x3 = await AsyncMainDemoTwo();
            string x4 = await AsyncMainDemoThree();

            DefaultLiteralExpressionsDemoOne();

            InferredTupleElementNamesDemoOne();

            PatternMatchingOnGenericTypeParametersDemoOne();

            ReadLine();
        }
    }
}
