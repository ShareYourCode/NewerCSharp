﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;

namespace CSharpSevenPointOneFeatures
{
    /// <summary>
    /// 泛型类型参数的模式匹配：可以对类型为泛型类型参数的变量使用模式匹配表达式
    /// </summary>
    public static class PatternMatchingOnGenericTypeParameters
    {
        public static void PatternMatchingOnGenericTypeParametersDemoOne()
        {
            PatternMatchingOnGenericTypeParametersDemoOne<Packet, KeepalivePacket>(new Packet());
            PatternMatchingOnGenericTypeParametersDemoOne<Packet, KeepalivePacket>(new KeepalivePacket());
            PatternMatchingOnGenericTypeParametersDemoOne<Packet, KeepalivePacket>(new SelfKeepalivePacket());

            PatternMatchingOnGenericTypeParametersDemoOne<Packet, SelfKeepalivePacket>(new Packet());
            PatternMatchingOnGenericTypeParametersDemoOne<Packet, SelfKeepalivePacket>(new KeepalivePacket());
            PatternMatchingOnGenericTypeParametersDemoOne<Packet, SelfKeepalivePacket>(new SelfKeepalivePacket());

            PatternMatchingOnGenericTypeParametersDemoOne<KeepalivePacket, KeepalivePacket>(new KeepalivePacket());
            PatternMatchingOnGenericTypeParametersDemoOne<KeepalivePacket, KeepalivePacket>(new SelfKeepalivePacket());

            PatternMatchingOnGenericTypeParametersDemoOne<KeepalivePacket, SelfKeepalivePacket>(new KeepalivePacket());
            PatternMatchingOnGenericTypeParametersDemoOne<KeepalivePacket, SelfKeepalivePacket>(new SelfKeepalivePacket());

            PatternMatchingOnGenericTypeParametersDemoOne<SelfKeepalivePacket, KeepalivePacket>(new SelfKeepalivePacket());
            PatternMatchingOnGenericTypeParametersDemoOne<SelfKeepalivePacket, SelfKeepalivePacket>(new SelfKeepalivePacket());
        }

        private static void PatternMatchingOnGenericTypeParametersDemoOne<T, U>(T packet) where T:Packet where U: KeepalivePacket
        {
            if (packet is U one) // C# 7.1 之前不支持
            {
                WriteLine($"Is Generic Type: {one}");
            }

            if (packet is SelfKeepalivePacket two) // C# 7.1 之前不支持
            {
                WriteLine($"Is Specific Type: {two}");
            }
            else if (packet is KeepalivePacket three) // C# 7.1 之前不支持
            {
                WriteLine($"Is Specific Type: {three}");
            }
            else if (packet is Packet four)
            {
                WriteLine($"Is Specific Type: {four}");
            }

            switch (packet)
            {
                case U five:  // C# 7.1 之前不支持
                    WriteLine($"Case Generic Type: {five}");
                    break;
            }

            switch (packet)
            {
                case SelfKeepalivePacket six:  // C# 7.1 之前不支持
                    WriteLine($"Case Specific Type: {six}");
                    break;
                case KeepalivePacket seven:  // C# 7.1 之前不支持
                    WriteLine($"Case Specific Type: {seven}");
                    break;
                case Packet eight:
                    WriteLine($"Case Specific Type: {eight}");
                    break;
            }
        }
    }

    public class Packet { }

    public class KeepalivePacket : Packet { }

    public class SelfKeepalivePacket : KeepalivePacket { }
}
