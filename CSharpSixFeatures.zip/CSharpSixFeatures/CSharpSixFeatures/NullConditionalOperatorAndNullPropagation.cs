﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;

namespace CSharpSixFeatures
{
    /// <summary>
    /// 空值判断
    /// </summary>
    public static class NullConditionalOperatorAndNullPropagation
    {
        public static void NullConditionalOperatorAndNullPropagationDemoOne()
        {
            SuperHero hero = new SuperHero();
            if (String.IsNullOrWhiteSpace(hero.SuperPower))
            {
                hero = null;
            }

            WriteLine(hero?.SuperPower ?? "You aint a super hero.");

            hero = new SuperHero("Fighting");

            WriteLine(hero?.SuperPower ?? "You aint a super hero.");
        }

        public static void NullConditionalOperatorAndNullPropagationDemoTwo()
        {
            List<SuperHero> superHeroes = null;
            SuperHero hero = new SuperHero();
            if (!String.IsNullOrWhiteSpace(hero.SuperPower))
            {
                superHeroes = new List<SuperHero>();
                superHeroes.Add(hero);
            }
            WriteLine(superHeroes?[0].SuperPower ?? "There is no such thing as super heros.");

            hero = new SuperHero("Fly");
            if (!String.IsNullOrWhiteSpace(hero.SuperPower))
            {
                SuperHero specificSuperHero = superHeroes?[0];
                superHeroes = new List<SuperHero>();
                try
                {
                    SuperHero firstSuperHero = superHeroes?[0];
                }
                catch { }
                superHeroes.Add(hero);
            }
            WriteLine(superHeroes?[0]?.SuperPower ?? "You aint a super hero." ?? "There is no such thing as super heros.");
        }

        public static void NullConditionalOperatorAndNullPropagationDemoThree()
        {
            Teacher teacher = new Teacher("Frankie Tang", 52);
            WriteLine($"FullName: {teacher.FullName}\nAge: {teacher.Age}");
        }
    }

    public class SuperHero
    {
        public SuperHero() { }

        public SuperHero(string superPower)
        {
            SuperPower = superPower;
        }

        public string SuperPower { get; set; }
    }

    public class Teacher : INotifyPropertyChanged
    {
        public Teacher() { }

        public Teacher(string fullName, int age)
        {
            FullName = fullName;
            Age = age;
        }

        private string _fullName;

        public string FullName
        {
            get { return _fullName; }
            set
            {
                _fullName = value;
                NotifyPropertyChanged(nameof(FullName));
            }
        }

        private int _age;

        public int Age
        {
            get { return _age; }
            set
            {
                _age = value;
                NotifyPropertyChanged(nameof(Age));
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;

        private void NotifyPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}
