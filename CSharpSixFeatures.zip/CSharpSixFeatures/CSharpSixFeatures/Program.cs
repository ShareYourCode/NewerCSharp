﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;
using static CSharpSixFeatures.StaticTypesAsUsing;
using static CSharpSixFeatures.StringInterpolation;
using static CSharpSixFeatures.DictionaryInitializers;
using static CSharpSixFeatures.AutoPropertyInitializers;
using static CSharpSixFeatures.NameOfExpression;
using static CSharpSixFeatures.AwaitInCatchAndFinallyBlock;
using static CSharpSixFeatures.NullConditionalOperatorAndNullPropagation;
using static CSharpSixFeatures.ExpressionBodiedFunctionAndProperty;
using static CSharpSixFeatures.ExceptionFiltering;
using static CSharpSixFeatures.ImprovedOverloadResolution;

namespace CSharpSixFeatures
{
    class Program
    {
        static void Main(string[] args)
        {
            StaticTypesAsUsingDemoOne();

            StringInterpolationDemoOne();

            StringInterpolationDemoTwo();

            StringInterpolationDemoThree();

            StringInterpolationDemoFour();

            StringInterpolationDemoFive();

            DictionaryInitializersDemoOne();

            AutoPropertyInitializersDemoOne();

            try
            {
                NameOfExpressionDemoOne();
            }
            catch (Exception ex)
            {
                WriteLine(ex.Message);
            }

            NameOfExpressionDemoTwo();

            Task.Factory.StartNew(() => AwaitInCatchAndFinallyBlockDemoOne());

            NullConditionalOperatorAndNullPropagationDemoOne();

            NullConditionalOperatorAndNullPropagationDemoTwo();

            NullConditionalOperatorAndNullPropagationDemoThree();

            WriteLine(ExpressionBodiedFunctionAndPropertyDemoOne(5, 8));

            ExpressionBodiedFunctionAndPropertyDemoTwo();

            ExpressionBodiedFunctionAndPropertyDemoThree();

            ExceptionFilteringDemoOne();

            ImprovedOverloadResolutionDemoOne();

            ReadLine();
        }
    }
}
