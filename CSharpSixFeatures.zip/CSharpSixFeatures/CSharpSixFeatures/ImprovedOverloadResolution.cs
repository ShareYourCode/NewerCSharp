﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;

namespace CSharpSixFeatures
{
    /// <summary>
    /// 改进了的重载解析
    /// 早期的编译器无法正确区分 Task.Run(Action) 和 Task.Run(Func<Task>())
    /// 所以在早期版本的 C# 中，使用方法组语法调用该方法将失败：Task.Run(DoThings);
    /// 因此在早期版本中，需要使用 lambda 表达式作为参数：Task.Run(() => DoThings());
    /// 而 C# 6 编译器正确地确定 Task.Run(Func<Task>()) 是更好的选择
    /// </summary>
    public static class ImprovedOverloadResolution
    {
        public static void ImprovedOverloadResolutionDemoOne()
        {
            var oldInvoke = Task.Run(() => DoThings());
            var newInvoke = Task.Run(DoThings);
            WriteLine(oldInvoke);
            WriteLine(newInvoke);
        }

        private static Task DoThings()
        {
            return Task.FromResult(0);
        }
    }
}
