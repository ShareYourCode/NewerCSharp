﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;

namespace CSharpSixFeatures
{
    /// <summary>
    /// 自动(实现)属性初始化器
    /// </summary>
    public static class AutoPropertyInitializers
    {
        public static void AutoPropertyInitializersDemoOne()
        {
            Employee employee = new Employee();
            WriteLine($"Name: {employee.Name}\nSalary: {employee.Salary}");
            employee.Name = "Tommy Jenkins";
            WriteLine($"Name: {employee.Name}\nSalary: {employee.Salary.ToString()}");
        }
    }

    public class Employee
    {
        public string Name { get; set; } = "Sammy Jenkins";

        public decimal Salary { get; } = 10000;
    }
}
