﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;

namespace CSharpSixFeatures
{
    /// <summary>
    /// 自动(实现)属性初始化器
    /// 只读属性除了可以在定义时初始化，还可以延迟到构造器中初始化
    /// </summary>
    public static class AutoPropertyInitializers
    {
        public static void AutoPropertyInitializersDemoOne()
        {
            Employee employee = new Employee();
            WriteLine($"Name: {employee.Name}\nSalary: {employee.Salary}");
            employee.Name = "Tommy Jenkins";
            WriteLine($"Name: {employee.Name}\nSalary: {employee.Salary.ToString()}");
            Employee anotherEmployee = new Employee("Sandy", "Chung");
            WriteLine($"NickName: {anotherEmployee.NickName}");
        }
    }

    public class Employee
    {
        public Employee() { }

        public Employee(string first, string last)
        {
            NickName = $"{first}*{last}";
        }

        public string Name { get; set; } = "Sammy Jenkins";

        public string NickName { get; }

        public decimal Salary { get; } = 10000;
    }
}
