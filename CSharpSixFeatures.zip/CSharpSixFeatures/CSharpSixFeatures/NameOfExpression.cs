﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;

namespace CSharpSixFeatures
{
    /// <summary>
    /// nameof 表达式
    /// </summary>
    public static class NameOfExpression
    {
        public static void NameOfExpressionDemoOne()
        {
            int? number = null;
            if (number == null)
            {
                throw new Exception($"{nameof(number)} is null");
            }
        }

        public static void NameOfExpressionDemoTwo()
        {
            Student student = new Student("Jackie Mo", 35);
            WriteLine($"FullName: {student.FullName}\nAge: {student.Age}");
            student.FullName = "Tony Jar";
            student.Age = 38;
            WriteLine($"FullName: {student.FullName}\nAge: {student.Age}");
        }
    }

    public class Student: INotifyPropertyChanged
    {
        public Student() { }

        public Student(string fullName, int age)
        {
            FullName = fullName;
            Age = age;
        }

        private string _fullName;

        public string FullName
        {
            get { return _fullName; }
            set
            {
                _fullName = value;
                NotifyPropertyChanged(nameof(FullName));
            }
        }

        private int _age;

        public int Age
        {
            get { return _age; }
            set
            {
                _age = value;
                NotifyPropertyChanged(nameof(Age));
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;

        private void NotifyPropertyChanged(string propertyName)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }
    }
}
