﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;

namespace CSharpSixFeatures
{
    /// <summary>
    /// Lambda 表达式作为函数体、属性值、索引器访问器体、运算符重载函数体、自定义类型强制转换函数体
    /// </summary>
    public static class ExpressionBodiedFunctionAndProperty
    {
        public static double ExpressionBodiedFunctionAndPropertyDemoOne(double x, double y) => x + y;

        public static void ExpressionBodiedFunctionAndPropertyDemoTwo() => WriteLine(nameof(ExpressionBodiedFunctionAndPropertyDemoTwo));

        public static void ExpressionBodiedFunctionAndPropertyDemoThree()
        {
            Person person = new Person();
            string fifthPerson = person[5];
            Person anotherPerson = new Person();
            string multiPerson = person + anotherPerson;
            string personString = (string)person;
            WriteLine($"{{{nameof(person)}.FullName}}: {person.FullName}; {fifthPerson}; {multiPerson}; {personString}");
        }
    }

    public class Person
    {
        public string FirstName { get; } = "Fiyaz";

        public string LastName { get; } = "Hasan";

        public string FullName => $"{FirstName} {LastName}";

        public string this[long id] => $"{FirstName}-{LastName}";

        public static string operator +(Person a, Person b) => $"{a.FullName}*{b.FullName}";

        public static implicit operator string(Person p) => $"({p.FirstName}).({p.LastName})";
    }
}
