﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;

namespace CSharpSixFeatures
{
    /// <summary>
    /// Lambda 表达式作为函数体以及属性值
    /// </summary>
    public static class ExpressionBodiedFunctionAndProperty
    {
        public static double ExpressionBodiedFunctionAndPropertyDemoOne(double x, double y) => x + y;

        public static void ExpressionBodiedFunctionAndPropertyDemoTwo()
        {
            Person person = new Person();
            WriteLine($"{{{nameof(person)}.FullName}}: {person.FullName}");
        }
    }

    public class Person
    {
        public string FirstName { get; } = "Fiyaz";

        public string LastName { get; } = "Hasan";

        public string FullName => $"{FirstName} {LastName}";
    }
}
