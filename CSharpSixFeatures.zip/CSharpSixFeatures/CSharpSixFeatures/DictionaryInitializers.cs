﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;

namespace CSharpSixFeatures
{
    /// <summary>
    /// 字典初始化器
    /// </summary>
    public static class DictionaryInitializers
    {
        public static void DictionaryInitializersDemoOne()
        {
            // 字典的旧初始化方式
            Dictionary<string, string> oldAlien = new Dictionary<string, string>()
            {
                { "Name", "Fizzy"},
                { "Planet", "Kepler-452b"}
            };

            // 字典的新初始化方式
            Dictionary<string, string> newAlien = new Dictionary<string, string>()
            {
                ["Name"] = "Fizzy",
                ["Planet"] = "Kepler-452b"
            };

            foreach (KeyValuePair<string, string> keyValuePair in oldAlien)
            {
                WriteLine(keyValuePair.Key + ": " + keyValuePair.Value + "\n");
            }

            foreach (KeyValuePair<string, string> keyValuePair in newAlien)
            {
                WriteLine(keyValuePair.Key + ": " + keyValuePair.Value + "\n");
            }
        }
    }
}
