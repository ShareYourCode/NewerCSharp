﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;

namespace CSharpSixFeatures
{
    /// <summary>
    /// 字符串插入
    /// </summary>
    public static class StringInterpolation
    {
        public static void StringInterpolationDemoOne()
        {
            string name = "Murphy Cooper";
            string planet = "Cooper Station";

            WriteLine($"{planet} is actually named after {name}");
        }

        public static void StringInterpolationDemoTwo()
        {
            string name = "Sammy Jenkins";
            double salary = 1000;

            WriteLine($"{name}'s monthly salary is {salary:C2}");
            WriteLine($"Man! This {name} is kind of a {(salary >= 1000 ? "rich guy" : "poor guy")}");
        }
    }
}
