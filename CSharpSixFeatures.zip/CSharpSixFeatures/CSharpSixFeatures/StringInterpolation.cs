﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;

namespace CSharpSixFeatures
{
    /// <summary>
    /// 字符串插入
    /// 如果内插表达式的计算结果为 null，则会使用一个空字符串
    /// 如果内插表达式的计算结果不是 null，通常会调用结果表达式的 ToString 方法
    /// 因为冒号 (:) 在具有内插表达式的项中具有特殊含义，为了在表达式中使用条件运算符，请将表达式放在括号内
    /// 要在内插字符串生成的文本中包含大括号 "{" 或 "}"，请使用两个大括号，即 "{{" 或 "}}"
    /// 在“逐字字符串”（以@前缀的字符串）内插字符串中，$ 标记必须出现 @ 标记之前
    /// </summary>
    public static class StringInterpolation
    {
        public static void StringInterpolationDemoOne()
        {
            string name = "Murphy Cooper";
            string planet = "Cooper Station";

            WriteLine($"{planet} is actually named after {name}");
        }

        public static void StringInterpolationDemoTwo()
        {
            double a = 3;
            double b = 4;
            WriteLine($"Area of the right triangle with legs of {a} and {b} is {0.5 * a * b}");
            WriteLine($"Length of the hypotenuse of the right triangle with legs of {a} and {b} is {CalculateHypotenuse(a, b)}");

            string name = "Sammy Jenkins";
            double salary = 1000;
            WriteLine($"{name}'s monthly salary is {salary:C2}");
            WriteLine($"Man! This {name.ToUpper()} is kind of a {(salary >= 1000 ? "rich guy" : "poor guy")}");
        }

        private static double CalculateHypotenuse(double leg1, double leg2) => Math.Sqrt(leg1 * leg1 + leg2 * leg2);

        public static void StringInterpolationDemoThree()
        {
            Tuple<string, decimal, int> item = new Tuple<string, decimal, int>("eggplant", 1.99m, 3);
            DateTime date = DateTime.Now;

            WriteLine($"On {date}, the price of {item.Item1} was {item.Item2} per {item.Item3} items.");
            WriteLine($"On {date:d}, the price of {item.Item1} was {item.Item2:c2} per {item.Item3} items.");
            WriteLine($"On {date:D}, the price of {item.Item1} was {item.Item2:C2} per {item.Item3} items.");
            WriteLine($"On {date.DayOfWeek}, the price of {item.Item1} was {item.Item2:C2} per {item.Item3} items.");
            WriteLine($"On {date:HH:mm}, the price of {item.Item1} was {item.Item2:C2} per {item.Item3} items.");
            WriteLine($"On {date:dddd, MMMM dd, yyyy}, the price of {item.Item1} was {item.Item2:C2} per {item.Item3} items.");
        }

        public static void StringInterpolationDemoFour()
        {
            Dictionary<string, int> inventory = new Dictionary<string, int>()
            {
                ["hammer, ball pein"] = 18,
                ["hammer, cross pein"] = 5,
                ["screwdriver, Phillips #2"] = 14
            };

            DateTime now = DateTime.Now;
            WriteLine($"Inventory on {now:d}");
            WriteLine($"|{"Item",-25}|{"Quantity",10}|");
            foreach (var item in inventory)
            {
                WriteLine($"|{item.Key,-25}|{item.Value,10}|");
            }
            WriteLine($"[{now,-20:d}] Hour [{now,-10:HH}] [{1063.342,15:N2}] feet");
        }

        public static void StringInterpolationDemoFive()
        {
            string name = "Horace";
            int age = 34;
            WriteLine($"He asked, \"Is your name {name}?\", but didn't wait for a reply :{{-}}");
            WriteLine($@"He asked, ""Is your name {name}?"", but didn't wait for a reply :{{-}}");
            WriteLine($@"He asked, \Is your name {name}?\, but didn't wait for a reply :{{-}}");
            WriteLine($"{name} is {age} year{(age == 1 ? "" : "s")} old.");

            var xs = new int[] { 1, 2, 7, 9 };
            var ys = new int[] { 7, 9, 12 };
            WriteLine($"Find the intersection of the {{{string.Join(", ", xs)}}} and {{{string.Join(", ", ys)}}} sets.");

            string userName = "Jane";
            string stringWithEscapes = $"C:\\Users\\{userName}\\Documents";
            string verbatimInterpolated = $@"C:\Users\{userName}\Documents";
            WriteLine(stringWithEscapes);
            WriteLine(verbatimInterpolated);
        }
    }
}
