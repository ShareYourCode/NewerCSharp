﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using static System.Console;

namespace CSharpSixFeatures
{
    /// <summary>
    /// 在 catch 和 finally 块中使用 await
    /// </summary>
    public static class AwaitInCatchAndFinallyBlock
    {
        public async static Task AwaitInCatchAndFinallyBlockDemoOne()
        {
            HttpClient client = new HttpClient();
            try
            {
                var result1 = await client.GetStringAsync("http://services.odata.org/V3/(S(cqe53nmm23wgasyeg2vvncim))/OData/OData.svc");
                WriteLine(result1);
                Console.WriteLine();
                throw new Exception();
            }
            catch
            {
                var result2 = await client.GetStringAsync("http://services.odata.org/V3/(S(cqe53nmm23wgasyeg2vvncim))/OData/OData.svc");
                WriteLine(result2);
                Console.WriteLine();
            }
            finally
            {
                var result3 = await client.GetStringAsync("http://services.odata.org/V3/(S(cqe53nmm23wgasyeg2vvncim))/OData/OData.svc");
                WriteLine(result3);
                Console.WriteLine();
            }
        }
    }
}
