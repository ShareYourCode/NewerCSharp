﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using static System.Console;

namespace CSharpEightFeatures
{
    /// <summary>
    /// 异步流
    /// 从 C# 8.0 开始，可以创建并以异步方式使用流。 返回异步流的方法有三个特点：
    /// 1）它是用 async 修饰符声明的
    /// 2）它将返回 IAsyncEnumerable<T>，可以使用 await foreach 语句来枚举它
    /// 3）该方法包含用于在异步流中返回连续元素的 yield return 语句
    /// </summary>
    public static class AsynchronousStreams
    {
        public static void AsynchronousStreamsDemoOne()
        {
            GenerateAsyncSequenceDemo();
        }

        async private static void GenerateAsyncSequenceDemo()
        {
            IAsyncEnumerable<int> result = GenerateAsyncSequence();
            await foreach (var item in result)
            {
                Write($"{item} ");
            }
            WriteLine();
        }

        private static async IAsyncEnumerable<int> GenerateAsyncSequence()
        {
            for (int i = 0; i < 20; i++)
            {
                await Task.Delay(100);
                yield return i;
            }
        }
    }
}
