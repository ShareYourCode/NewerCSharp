﻿using System;
using System.Collections.Generic;
using System.Text;
using static System.Console;

namespace CSharpEightFeatures
{
    /// <summary>
    /// Readonly 结构体成员
    /// </summary>
    public static class ReadonlyStructMembers
    {
        public static void ReadonlyStructMembersDemoOne()
        {
            Point point = new Point();
            string pointStr = point.ToString();
            WriteLine(pointStr);
            point.Translate(5, 6);
        }
    }

    /// <summary>
    /// C# 8.0 前只能将 readonly 修饰符应用于 struct
    /// 而 C# 8.0 后可将 readonly 修饰符应用于结构的任何成员，它指示该成员不会修改状态
    /// 这比将 readonly 修饰符应用于 struct 声明更精细
    /// </summary>
    public struct Point
    {
        public double X { get; }

        public double Y { get; set; }
        readonly public double Z { get; }

        public double Distance => Math.Sqrt(X * X + Y * Y);

        readonly public double Perspect => Math.Sqrt(X * X + Y * Y + X * Y);


        // 编译器警告（warning CS8656），因为 ToString 访问 Distance 属性，该属性未标记为 readonly
        readonly public override string ToString() =>
            $"({X}, {Y}) is {Distance} from the origin"; 

        public readonly void Translate(int xOffset, int yOffset)
        {
            WriteLine($"({X}, {Y}) is {Perspect} from the origin");
        }
    }
}
