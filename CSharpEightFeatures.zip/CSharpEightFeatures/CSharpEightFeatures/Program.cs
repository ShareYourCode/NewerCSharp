﻿using System;
using static System.Console;
using static CSharpEightFeatures.ReadonlyStructMembers;
using static CSharpEightFeatures.DefaultInterfaceMembers;
using static CSharpEightFeatures.PatternMatchingEnhancements;
using static CSharpEightFeatures.UsingDeclarations;
using static CSharpEightFeatures.NullableReferenceTypes;
using static CSharpEightFeatures.IndicesAndRanges;
using static CSharpEightFeatures.AsynchronousStreams;

namespace CSharpEightFeatures
{
    class Program
    {
        static void Main(string[] args)
        {
            ReadonlyStructMembersDemoOne();

            DefaultInterfaceMembersDemoOne();

            PatternMatchingEnhancementsDemoOne();

            UsingDeclarationsDemoOne();

            StaticLocalFunctions staticLocalFunctions = new StaticLocalFunctions();
            staticLocalFunctions.StaticLocalFunctionsDemoOne();

            NullableReferenceTypesDemoOne();

            NullableReferenceTypesDemoTwo();

            NullableReferenceTypesDemoThree();

            NullableReferenceTypesDemoFour();

            IndicesAndRangesDemoOne();

            IndicesAndRangesDemoTwo();

            AsynchronousStreamsDemoOne();

            ReadLine();
        }
    }
}
