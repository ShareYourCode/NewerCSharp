﻿using System;
using System.Collections.Generic;
using System.Text;
using static System.Console;
#nullable enable

namespace CSharpEightFeatures
{
    /// <summary>
    /// 可为空引用类型：C# 8.0 后可以定义“可为空引用类型”的变量
    /// 但使用了“可为空引用类型”后会引发CS8632警告（应仅在 “#nullable” 上下文中的代码中使用可为 null 的引用类型的注释）
    /// 可以使用 #nullable enable 消除警告CS8632
    /// 也可以在 .csproj 文件中添加 <Nullable>enable</Nullable> 对整个项目消除警告CS8632
    /// 使用了“#nullable enable”或“<Nullable>enable</Nullable>”的上下文称为“可为空注释上下文”
    /// 在“可为空注释上下文”中，当变量为 null，对其使用“.”会引发CS8602警告（取消引用可能的空引用）
    /// 此时可以使用“null 包容运算符 (!)”消除警告CS8602
    /// </summary>
    public static class NullableReferenceTypes
    {
        public static void NullableReferenceTypesDemoOne()
        {
            string? name = "Test";
            int len = name.Length;
            WriteLine($"{name}: {len}");
            name = null;
            try
            {
                // 在“可为空注释上下文”中变量为 null，对其使用“.”会引发CS8602警告（取消引用可能的空引用）
                len = name.Length;
            }
            catch (Exception exp)
            {
                name = exp.Message;
                // 此时 name 不为 null，所以不会引发CS8602警告
                len = name.Length;
                WriteLine($"{name}: {len}");
            }
            finally
            {
                // 经过 catch 后的 name 不为 null，但此时编译器仍发出CS8602警告，此时可以使用“null 包容运算符 (!)”消除警告CS8602
                len = name!.Length;
                WriteLine($"{name}: {len}");
            }
        }

        public static void NullableReferenceTypesDemoTwo()
        {
            string? name = "Test";
            int len = name.Length;
            WriteLine($"{name}: {len}");
            name = null;
            try
            {
                // 在“可为空注释上下文”中变量为 null，对其使用“.”会引发CS8602警告（取消引用可能的空引用），此时可以使用“null 包容运算符 (!)”消除警告CS8602
                len = name!.Length;
            }
            catch (Exception exp)
            {
                name = exp.Message;
                // 此时 name 不为 null，所以不会引发CS8602警告
                len = name.Length;
                WriteLine($"{name}: {len}");
            }
            finally
            {
                // 经过 catch 后的 name 不为 null，但此时编译器仍发出CS8602警告，此时可以使用“null 包容运算符 (!)”消除警告CS8602
                len = name!.Length;
                WriteLine($"{name}: {len}");
            }
        }

        public static void NullableReferenceTypesDemoThree()
        {
            string name = "Test";
            int len = name.Length;
            WriteLine($"{name}: {len}");
            name = null;
            try
            {
                // 在“可为空注释上下文”中变量为 null，对其使用“.”会引发CS8602警告（取消引用可能的空引用）
                len = name.Length;
            }
            catch (Exception exp)
            {
                name = exp.Message;
                // 此时 name 不为 null，所以不会引发CS8602警告
                len = name.Length;
                WriteLine($"{name}: {len}");
            }
            finally
            {
                // 经过 catch 后的 name 不为 null，但此时编译器仍发出CS8602警告，此时可以使用“null 包容运算符 (!)”消除警告CS8602 
                len = name!.Length;
                WriteLine($"{name}: {len}");
            }
        }

        public static void NullableReferenceTypesDemoFour()
        {
            string name = "Test";
            int len = name.Length;
            WriteLine($"{name}: {len}");
            name = null;
            try
            {
                // 在“可为空注释上下文”中变量为 null，对其使用“.”会引发CS8602警告（取消引用可能的空引用），此时可以使用“null 包容运算符 (!)”消除警告CS8602
                len = name!.Length;
            }
            catch (Exception exp)
            {
                name = exp.Message;
                // 此时 name 不为 null，所以不会引发CS8602警告
                len = name.Length;
                WriteLine($"{name}: {len}");
            }
            finally
            {
                // 经过 catch 后的 name 不为 null，但此时编译器仍发出CS8602警告，此时可以使用“null 包容运算符 (!)”消除警告CS8602 
                len = name!.Length;
                WriteLine($"{name}: {len}");
            }
        }
    }
}
