﻿using System;
using System.Collections.Generic;
using System.Text;
using static System.Console;

namespace CSharpEightFeatures
{
    /// <summary>
    /// 默认接口成员：C# 8.0 后可以为接口中的成员提供实现
    /// </summary>
    public static class DefaultInterfaceMembers
    {
        public static void DefaultInterfaceMembersDemoOne()
        {
            ICustomer cus = new Customer();
            IOrder ord = new Order();
            string orderResult = cus.NewSetOrder(ord);
            WriteLine(orderResult);
            WriteLine(cus.SetOrder(ord));
            WriteLine(cus.NewOverrideSetOrder(ord));
        }
    }

    public class Order : IOrder
    {
        public DateTime Purchased => DateTime.Now;

        public decimal Cost => 99.5M;
    }

    public class Customer : ICustomer
    {
        public IEnumerable<IOrder> PreviousOrders => throw new NotImplementedException();

        public DateTime DateJoined => throw new NotImplementedException();

        public DateTime? LastOrder => throw new NotImplementedException();

        public string Name { get => throw new NotImplementedException(); set => throw new NotImplementedException(); }

        public IDictionary<DateTime, string> Reminders => throw new NotImplementedException();

        public string SetOrder(IOrder order)
        {
            return $"{order.Cost}_{order.Purchased}";
        }

        public string NewOverrideSetOrder(IOrder order) // 覆盖了接口中的对应方法
        {
            return $"{order.Purchased}_{order.Cost}";
        }
    }

    public interface ICustomer
    {
        IEnumerable<IOrder> PreviousOrders { get; }

        DateTime DateJoined { get; }
        DateTime? LastOrder { get; }
        string Name { get; set; }
        IDictionary<DateTime, string> Reminders { get; }

        string SetOrder(IOrder order);

        string NewSetOrder(IOrder order)
        {
            return $"{order.Cost}-{order.Purchased}";
        }

        string NewOverrideSetOrder(IOrder order)
        {
            return $"{order.Purchased}-{order.Cost}";
        }
    }

    public interface IOrder
    {
        DateTime Purchased { get; }
        decimal Cost { get; }
    }
}
