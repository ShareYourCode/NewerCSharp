﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using static System.Console;

namespace CSharpEightFeatures
{
    /// <summary>
    /// 索引和范围
    /// 范围和索引为在数组中指定子范围（Span<T> 或 ReadOnlySpan<T>）提供了简洁语法
    /// 此语言支持依赖于两个新类型和两个新运算符：
    /// 1）System.Index 表示一个序列索引
    /// 2）^ 运算符，指定一个索引与序列末尾相关
    /// 3）System.Range 表示序列的子范围
    /// 4）范围运算符 (..)，用于指定范围的开始和末尾，就像操作数一样
    /// 以数组 sequence 为例（假设它有9个元素）， 0 索引与 sequence[0] 相同，^0 索引与 sequence[sequence.Length] 相同
    /// 对于任何数字 n，索引 ^n 与 sequence.Length - n 相同，如 sequence[^2] = sequence[9 - 2] = sequence[7]
    /// 范围指定范围的开始和末尾，包括此范围的开始，但不包括此范围的末尾，这表示此范围包含开始但不包含末尾
    /// 范围 [0..^0] 表示整个范围，就像 [0..sequence.Length] 表示整个范围
    /// 还可以将索引声明为变量，如 Index idx = ^3; 然后将索引作为数组的索引，如 sequence[idx]
    /// 还可以将范围声明为变量，如 Range phrase = 1..4; 然后将范围作为数组的索引，如 sequence[phrase]
    /// </summary>
    public static class IndicesAndRanges
    {
        public static void IndicesAndRangesDemoOne()
        {
            string[] words = new string[]
            {
                            // index from start    index from end
                "The",      // 0                   ^9
                "quick",    // 1                   ^8
                "brown",    // 2                   ^7
                "fox",      // 3                   ^6
                "jumped",   // 4                   ^5
                "over",     // 5                   ^4
                "the",      // 6                   ^3
                "lazy",     // 7                   ^2
                "dog"       // 8                   ^1
            };              // 9 (or words.Length) ^0

            WriteLine(string.Join(", ", words));
            WriteLine();

            string lastWord = words[^1];
            WriteLine($"The last word is {lastWord}");

            string[] quickBrownFox = words[1..4];
            WriteLine(string.Join(", ", quickBrownFox));

            string[] lazyDog = words[^2..^0];
            WriteLine(string.Join(", ", lazyDog));

            string[] allWords = words[..]; // contains "The" through "dog".
            WriteLine(string.Join(", ", allWords));

            string[] firstPhrase = words[..4]; // contains "The" through "fox"
            WriteLine(string.Join(", ", firstPhrase));

            string[] lastPhrase = words[6..]; // contains "the", "lazy" and "dog"
            WriteLine(string.Join(", ", lastPhrase));

            Index idx = ^3;
            WriteLine($"IsFromEnd: {idx.IsFromEnd}, Value: {idx.Value}");
            string specificText = words[idx];
            WriteLine(specificText);

            Range phrase = 1..4;
            WriteLine($"Start: {phrase.Start}, End: {phrase.End}");
            string[] text = words[phrase];
            WriteLine(string.Join(", ", text));
        }

        public static void IndicesAndRangesDemoTwo()
        {
            var numbers = Enumerable.Range(0, 100).ToArray();
            int x = 12;
            int y = 25;
            int z = 36;

            WriteLine($"{numbers[^x]} is the same as {numbers[numbers.Length - x]}");
            WriteLine($"{numbers[x..y].Length} is the same as {y - x}");

            WriteLine("numbers[x..y] and numbers[y..z] are consecutive and disjoint:");
            Span<int> x_y = numbers[x..y]; // 等价于 int[] x_y = numbers[x..y]
            Span<int> y_z = numbers[y..z];
            WriteLine($"\tnumbers[x..y] is {x_y[0]} through {x_y[^1]}, numbers[y..z] is {y_z[0]} through {y_z[^1]}");

            WriteLine("numbers[x..^x] removes x elements at each end:");
            Span<int> x_x = numbers[x..^x];
            WriteLine($"\tnumbers[x..^x] starts with {x_x[0]} and ends with {x_x[^1]}");

            WriteLine("numbers[..x] means numbers[0..x] and numbers[x..] means numbers[x..^0]");
            Span<int> start_x = numbers[..x];
            Span<int> zero_x = numbers[0..x];
            WriteLine($"\t{start_x[0]}..{start_x[^1]} is the same as {zero_x[0]}..{zero_x[^1]}");
            Span<int> z_end = numbers[z..];
            Span<int> z_zero = numbers[z..];
            WriteLine($"\t{z_end[0]}..{z_end[^1]} is the same as {z_zero[0]}..{z_zero[^1]}");
        }
    }
}
