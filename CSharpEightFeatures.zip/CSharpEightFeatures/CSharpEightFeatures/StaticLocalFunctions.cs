﻿using System;
using System.Collections.Generic;
using System.Text;
using static System.Console;

namespace CSharpEightFeatures
{
    /// <summary>
    /// 静态本地函数：可以向本地函数添加 static 修饰符，以确保本地函数不会从封闭范围捕获（引用）任何变量
    /// </summary>
    public class StaticLocalFunctions
    {
        public void StaticLocalFunctionsDemoOne()
        {
            StaticLocalFunctions svc = new StaticLocalFunctions();
            int result = svc.M();
            WriteLine(result);
        }

        private int M()
        {
            int y;
            LocalFunction();
            y += Add(7, 12);
            return y;

            void LocalFunction() => y = 5;
            //! static void StaticLocalFunction() => y = 8; // 静态本地函数不能包含对“y”的引用
            static int Add(int left, int right) => left + right;
        }
    }
}
