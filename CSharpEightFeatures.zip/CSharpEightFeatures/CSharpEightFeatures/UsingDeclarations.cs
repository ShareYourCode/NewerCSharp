﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using static System.Console;

namespace CSharpEightFeatures
{
    /// <summary>
    /// using 声明：using 声明是前面带 using 关键字的变量声明，它指示编译器声明的变量应在封闭范围的末尾进行处理
    /// </summary>
    public static class UsingDeclarations
    {
        public static void UsingDeclarationsDemoOne()
        {
            List<string> lineList = new List<string>
            {
                "This is First Line.",
                "This is Second Line.",
                "This is Third Line.",
                "This is Fourth Line.",
            };

            WriteLinesToFile(lineList);
            WriteLine("Please check WriteLines2.txt file.");
            WriteLinesToFileClassic(lineList);
            WriteLine("Please check WriteLines3.txt file.");
        }

        /// <summary>
        /// 当到达方法的右括号时，将对该文件进行处理（像旧语法一样，编译器将生成对 Dispose() 的调用），这是声明 file 的范围的末尾
        /// </summary>
        /// <param name="lines"></param>
        private static void WriteLinesToFile(IEnumerable<string> lines)
        {
            using var file = new StreamWriter("WriteLines2.txt");
            foreach (string line in lines)
            {
                // If the line doesn't contain the word 'Second', write the line to the file.
                if (!line.Contains("Second"))
                {
                    file.WriteLine(line);
                }
            }
            // file is disposed here
        }

        private static void WriteLinesToFileClassic(IEnumerable<string> lines)
        {
            using (var file = new System.IO.StreamWriter("WriteLines3.txt"))
            {
                foreach (string line in lines)
                {
                    // If the line doesn't contain the word 'Second', write the line to the file.
                    if (!line.Contains("Second"))
                    {
                        file.WriteLine(line);
                    }
                }
            } // file is disposed here
        }
    }
}
