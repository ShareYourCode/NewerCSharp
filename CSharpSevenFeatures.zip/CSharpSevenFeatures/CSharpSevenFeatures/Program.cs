﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static CSharpSevenFeatures.OutVariables;
using static CSharpSevenFeatures.BinaryLiterals;
using static CSharpSevenFeatures.DigitSeparators;
using static CSharpSevenFeatures.Tuples;
using static CSharpSevenFeatures.LocalFunctions;
using static CSharpSevenFeatures.RefReturnsAndLocals;
using static CSharpSevenFeatures.PatternMatching;
using static CSharpSevenFeatures.MoreExpressionBodiedMembers;
using static CSharpSevenFeatures.ThrowExpressions;

namespace CSharpSevenFeatures
{
    class Program
    {
        static void Main(string[] args)
        {
            OutVariablesDemoOne();

            BinaryLiteralsDemoOne();

            DigitSeparatorsDemoOne();

            TuplesDemoOne();

            LocalFunctionsDemoOne();

            LocalFunctionsDemoTwo(18);

            RefReturnsAndLocalsDemoOne();

            PatternMatchingDemoOne();

            PatternMatchingDemoTwo();

            PatternMatchingDemoThree();

            PatternMatchingDemoFour();

            MoreExpressionBodiedMembersDemoOne();

            ThrowExpressionsDemoOne();
        }
    }
}
