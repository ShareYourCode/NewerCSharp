﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;

namespace CSharpSevenFeatures
{
    /// <summary>
    /// 数字分隔符
    /// </summary>
    public static class DigitSeparators
    {
        public static void DigitSeparatorsDemoOne()
        {
            int[] numbersWithDigitSeparators = { 1_000, 0b1, 0b1_0000, 3___2, 0x00_1A0, 1__000_00___0,
                0xAB_CD_EF, 0b10__00_00, 0b1010_1011_1100_1101_1110_1111 };

            foreach (int eachNumber in numbersWithDigitSeparators)
            {
                Write(eachNumber + "; ");
            }
            WriteLine();
        }
    }
}
