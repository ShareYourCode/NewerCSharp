﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;

namespace CSharpSevenFeatures
{
    /// <summary>
    /// 数字分隔符
    /// </summary>
    public static class DigitSeparators
    {
        public static void DigitSeparatorsDemoOne()
        {
            const int sixteen = 0b0001_0000;
            const int thirtyTwo = 0b0010_0000;
            const int sixtyFour = 0b0100_0000;
            const int oneHundredTwentyEight = 0b1000_0000;
            const long billionsAndBillions = 100_000_000_000;
            const double avogadroConstant = 6.022_140_857_747_474e23;
            const decimal goldenRatio = 1.618_033_988_749_894_848_204_586_834_365_638_117_720_309_179M;
            WriteLine(sixteen);
            WriteLine(thirtyTwo);
            WriteLine(sixtyFour);
            WriteLine(oneHundredTwentyEight);
            WriteLine(billionsAndBillions);
            WriteLine(avogadroConstant);
            WriteLine(goldenRatio);

            int[] numbersWithDigitSeparators = { 1_000, 0b1, 0b1_0000, 3___2, 0x00_1A0, 1__000_00___0,
                0xAB_CD_EF, 0b10__00_00, 0b1010_1011_1100_1101_1110_1111 };

            foreach (int eachNumber in numbersWithDigitSeparators)
            {
                Write(eachNumber + "; ");
            }
            WriteLine();
        }
    }
}
