﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;

namespace CSharpSevenFeatures
{
    /// <summary>
    /// 局部函数（本地函数）
    /// </summary>
    public static class LocalFunctions
    {
        private static int LocalFunctionsDemoOne(int[] values)
        {
            int sum = 7;
            foreach (int value in values)
            {
                Add(value);
            }
            return sum;

            void Add(int s) => sum += s;
        }

        private static int LocalFunctionsDemoTwo(int[] values)
        {
            int sum = 7;
            foreach (int value in values)
            {
                Add(value);
            }

            void Add(int s)
            {
                sum--;
                sum += s;
            }
            return sum;
        }

        public static void LocalFunctionsDemoOne()
        {
            int[] numbers = { 1, 2, 4, 8, 16, 32 };

            int total = LocalFunctionsDemoOne(numbers);
            WriteLine($"Sum: {total}");

            int sum = LocalFunctionsDemoTwo(numbers);
            WriteLine($"Sum: {sum}");
        }

        public static void LocalFunctionsDemoTwo(int max)
        {
            Func<int, bool> even = (number) => number % 2 == 0; // 使用委托实现局部函数
            foreach (var number in Enumerable.Range(0, 10).Where(even))
            {
                Write(number + "; ");
            }
            WriteLine();

            foreach (var number in Enumerable.Range(0, 10).Where(odd))
            {
                Write(number + "; ");
            }
            bool odd(int number)
            {
                return number % 2 != 0;
            }
            WriteLine();

            IEnumerable<int> result()
            {
                int next = max + 1;
                yield return 1;
                yield return 2;
                yield return next;
            }
            int[] res = result().ToArray();
            foreach (int item in res)
            {
                Write(item + "; ");
            }
            WriteLine();

            WriteLine(minus(9, 7).Result);
            async Task<int> minus(int x, int y)
            {
                return (x - y);
            }
            WriteLine(minus(7, 9).Result);
        }
    }
}
