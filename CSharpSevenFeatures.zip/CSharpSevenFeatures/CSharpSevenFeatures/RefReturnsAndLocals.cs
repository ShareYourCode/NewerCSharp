﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;

namespace CSharpSevenFeatures
{
    /// <summary>
    /// Ref 返回
    /// </summary>
    public static class RefReturnsAndLocals
    {
        public static void RefReturnsAndLocalsDemoOne()
        {
            int[] numbers = { 1, 2, 4, 8 };

            ref int Get(int[] array, int index) => ref array[index];

            int firstNumber = Get(numbers, 0);
            ref int lastNumber = ref Get(numbers, numbers.Length - 1);
            WriteLine($"First number: {firstNumber}, Last number: {lastNumber}");
            firstNumber = 10;
            lastNumber = 10;
            WriteLine($"First number: {numbers[0]}, Last number: {numbers[numbers.Length - 1]}");
        }
    }
}
