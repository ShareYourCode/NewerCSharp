﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;

namespace CSharpSevenFeatures
{
    /// <summary>
    /// Ref 返回和 Ref 本地变量（Ref 局部变量）
    /// Ref 本地变量（Ref 局部变量）和返回结果不可用于异步方法
    /// </summary>
    public static class RefReturnsAndLocals
    {
        public static void RefReturnsAndLocalsDemoOne()
        {
            int[] numbers = { 1, 2, 4, 8 };

            // 必须将 ref 关键字添加到方法签名和方法中的所有 return 语句中，这清楚地表明，该方法在整个方法中通过引用返回
            ref int Get(int[] array, int index) => ref array[index];

            int GetOrd(int[] array, int index) => array[index];

            int firstNumber = Get(numbers, 0); // 可以将 ref return 分配给值变量，复制返回值，返回值的副本
            ref int lastNumber = ref Get(numbers, numbers.Length - 1); // 可以将 ref return 分配给 ref 变量，获取引用
            //! ref int secondNumber = GetOrd(numbers, 1); // 不可向 ref 本地变量（ref 局部变量）赋予标准方法返回值
            WriteLine($"First number: {firstNumber}, Last number: {lastNumber}");
            firstNumber = 10;
            lastNumber = 10;
            WriteLine($"First number: {numbers[0]}, Last number: {numbers[numbers.Length - 1]}");
        }
    }
}
