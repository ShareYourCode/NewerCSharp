﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;

namespace CSharpSevenFeatures
{
    /// <summary>
    /// out 变量
    /// </summary>
    public static class OutVariables
    {
        public static void OutVariablesDemoOne()
        {
            string str = "456";
            if (Int32.TryParse(str, out int x))
            {
                WriteLine(x);
            }
            else
            {
                WriteLine($"{str} is not int");
            }
            str = "4s6";
            if (Int32.TryParse(str, out int y))
            {
                WriteLine(y);
            }
            else
            {
                WriteLine($"{str} is not int");
            }
            str = "789";
            if (Int32.TryParse(str, out var r))
            {
                WriteLine(r);
            }
            else
            {
                WriteLine($"{str} is not int");
            }
            str = "t89";
            if (Int32.TryParse(str, out var z))
            {
                WriteLine(z);
            }
            else
            {
                WriteLine($"{str} is not int");
            }
        }
    }
}
