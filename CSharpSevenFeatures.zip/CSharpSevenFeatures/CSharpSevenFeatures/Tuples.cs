﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;

namespace CSharpSevenFeatures
{
    /// <summary>
    /// 元组
    /// </summary>
    public static class Tuples
    {
        private static Tuple<int, int> TuplesDemoOne(int[] values)
        {
            var r = new Tuple<int, int>(12, 35);
            return r;
        }

        private static Tuple<int, int> TuplesDemoTwo(int[] values)
        {
            var r = Tuple.Create<int, int>(12, 35);
            return r;
        }

        private static (int, int) TuplesDemoThree(int[] values)
        {
            var r = (12, 35);
            return r;
        }

        private static (int count, int sum) TuplesDemoFour(int[] values)
        {
            var r = (12, 35);
            return r;
        }

        private static (int count, int sum) TuplesDemoFive(int[] values)
        {
            var r = (count: 12, sum: 35);
            return r;
        }

        private static (int count, int sum) TuplesDemoSix(int[] values)
        {
            var r = (c: 12, s: 35);
            return r;
        }

        private static (int count, int sum) TuplesDemoSeven(int[] values)
        {
            var r = (c: 12, s: 35);
            foreach (int value in values)
            {
                r = (r.c + 1, r.s + value);
            }
            return r;
        }

        private static (int count, int sum) TuplesDemoEight(int[] values)
        {
            var r = (c: 12, s: 35);
            foreach (int value in values)
            {
                r.c++;
                r.s += value;
            }
            return r;
        }

        public static void TuplesDemoOne()
        {
            int[] numbers = { 1, 2, 4, 8, 16, 32 };

            Tuple<int, int> t1 = TuplesDemoOne(numbers);
            WriteLine($"Count: {t1.Item1}, Sum: {t1.Item2}");

            Tuple<int, int> t2 = TuplesDemoTwo(numbers);
            WriteLine($"Count: {t2.Item1}, Sum: {t2.Item2}");

            (int, int) t3 = TuplesDemoThree(numbers);
            WriteLine($"Count: {t3.Item1}, Sum: {t3.Item2}");

            var t4 = TuplesDemoFour(numbers);
            WriteLine($"Count: {t4.count}, Sum: {t4.sum}");
            var (count, sum) = TuplesDemoFour(numbers);
            WriteLine($"Count: {count}, Sum: {sum}");

            var t5 = TuplesDemoFive(numbers);
            WriteLine($"Count: {t5.count}, Sum: {t5.sum}");
            WriteLine($"Count: {t5.Item1}, Sum: {t5.sum}");
            (int Count, int Sum) = TuplesDemoFive(numbers);
            WriteLine($"Count: {Count}, Sum: {Sum}");

            var t6 = TuplesDemoSix(numbers);
            WriteLine($"Count: {t6.count}, Sum: {t6.sum}");
            WriteLine($"Count: {t6.Item1}, Sum: {t6.Item2}");
            var (c, s) = TuplesDemoSix(numbers);
            WriteLine($"Count: {c}, Sum: {s}");

            (var Counting, int Summary) = TuplesDemoSeven(numbers);
            WriteLine($"Count: {Counting}, Sum: {Summary}");

            var t8 = TuplesDemoEight(numbers);
            WriteLine($"Count: {t8.count}, Sum: {t8.sum}");
            WriteLine($"Count: {t8.count}, Sum: {t8.Item2}");
        }
    }
}
