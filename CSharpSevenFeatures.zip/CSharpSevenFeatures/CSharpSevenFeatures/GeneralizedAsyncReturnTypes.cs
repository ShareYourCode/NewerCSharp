﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharpSevenFeatures
{
    /// <summary>
    /// 通用异步返回类型：ValueTask<T>
    /// </summary>
    public static class GeneralizedAsyncReturnTypes
    {
        public static ValueTask<int> CachedFunc()
        {
            return (Cache) ? new ValueTask<int>(CacheResult) : new ValueTask<int>(LoadCache());
        }
        private static bool Cache = false;
        private static int CacheResult;
        private static async Task<int> LoadCache()
        {
            // simulate async work:
            await Task.Delay(100);
            Cache = true;
            CacheResult = 100;
            return CacheResult;
        }
    }
}
