﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;

namespace CSharpSevenFeatures
{
    /// <summary>
    /// 二进制字面量
    /// </summary>
    public static class BinaryLiterals
    {
        public static void BinaryLiteralsDemoOne()
        {
            int[] decimalNumbers = { 0, 1, 2, 4, 8, 16, 32 };
            int[] numbersWithBinary = { 0b0, 0b1, 0b10, 0b100, 0b1000, 0b10000, 32 };

            foreach (int eachNumber in decimalNumbers)
            {
                Write(eachNumber + "; ");
            }
            WriteLine();

            foreach (int eachNumber in numbersWithBinary)
            {
                Write(eachNumber + "; ");
            }
            WriteLine();
        }
    }
}
