﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;

namespace CSharpSevenFeatures
{
    /// <summary>
    /// Lambda 表达式作为函数体、构造函数体、析构函数体、属性值以及属性访问器体、
    /// 索引器访问器体、运算符重载函数体、自定义类型强制转换函数体
    /// </summary>
    public static class MoreExpressionBodiedMembers
    {
        public static void MoreExpressionBodiedMembersDemoOne()
        {
            Person person = new Person(26);
            WriteLine($"FullName: {person.FullName}; NickName: {person.NickName}; Age: {person.Age}");
            person.AddAge();
            WriteLine($"{{FullName}}: {person.FullName}; NickName: {person.NickName}; Age: {person.Age}");
            string fifthPerson = person[5];
            WriteLine($"Fifth person: {fifthPerson}");
            Person anotherPerson = new Person(32);
            string multiPerson = person + anotherPerson;
            WriteLine($"Multi person: {multiPerson}");
            string personString = (string)person;
            WriteLine($"PersonString: {personString}");
        }
    }

    public class Person
    {
        public Person(int age) => Age = age;

        ~Person() => Age = -1;

        public int Age { get; set; } = 1;

        public string FirstName { get; } = "Fiyaz";

        public string LastName { get; } = "Hasan";

        public string FullName => $"{FirstName} {LastName}";

        public string NickName
        {
            get => $"{FullName}+{Age}";
            set => value = $"{value}+{Age}";
        }

        public string this[long id] => $"{FirstName}-{LastName}";

        public static string operator +(Person a, Person b) => $"{a.FullName}*{b.FullName}";

        public static implicit operator string(Person p) => $"({p.FirstName}).({p.LastName})";

        public double AddAge() => ++Age;
    }
}
