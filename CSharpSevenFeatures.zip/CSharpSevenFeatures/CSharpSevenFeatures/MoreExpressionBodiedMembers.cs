﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;

namespace CSharpSevenFeatures
{
    /// <summary>
    /// Lambda 表达式作为函数体、构造函数体、析构函数体、属性值以及属性访问器体
    /// </summary>
    public static class MoreExpressionBodiedMembers
    {
        public static void MoreExpressionBodiedMembersDemoOne()
        {
            Person person = new Person(26);
            WriteLine($"FullName: {person.FullName}; NickName: {person.NickName}; Age: {person.Age}");
            person.AddAge();
            WriteLine($"{{FullName}}: {person.FullName}; NickName: {person.NickName}; Age: {person.Age}");
        }
    }

    public class Person
    {
        public Person(int age) => Age = age;

        ~Person() => Age = -1;

        public int Age { get; set; } = 1;

        public string FirstName { get; } = "Fiyaz";

        public string LastName { get; } = "Hasan";

        public string FullName => $"{FirstName} {LastName}";

        public string NickName
        {
            get => $"{FullName}+{Age}";
            set => value = $"{value}+{Age}";
        }

        public double AddAge() => ++Age;
    }
}
