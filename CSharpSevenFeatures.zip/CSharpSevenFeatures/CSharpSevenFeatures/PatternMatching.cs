﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;

namespace CSharpSevenFeatures
{
    /// <summary>
    /// 模式匹配
    /// </summary>
    public static class PatternMatching
    {
        private static void PatternMatchingDemoOne(object item)
        {
            if (item is null) return; // constant pattern "null"
            if (!(item is int i)) return; // type pattern pattern "int i"
            WriteLine(new string('*', i));
        }

        private static void PatternMatchingDemoTwo(object item)
        {
            if (item is string s && s.Length is int len && len > 2)
            {
                WriteLine(s.Length);
            }
        }

        public static void PatternMatchingDemoThree(object item)
        {
            if (item is var x) // A match to a var pattern always succeeds
            {
                WriteLine(item == x); // prints true
            }
        }

        private static void PatternMatchingDemoFour(Shape shape)
        {
            switch (shape) // Switch on anything
            {
                case Rectangle s when (s.Length == s.Height):
                    WriteLine($"{s.Length} x {s.Height} square");
                    break;
                case Rectangle r:
                    WriteLine($"{r.Length} x {r.Height} rectangle");
                    break;
                case Circle c:
                    WriteLine($"circle with radius {c.Radius}");
                    break;
                case null:
                    throw new ArgumentNullException(nameof(shape));
                default:
                    WriteLine("<unknown shape>");
                    break;
            }
        }

        public static void PatternMatchingDemoOne()
        {
            object obj = 4;
            PatternMatchingDemoOne(obj);
            obj = null;
            PatternMatchingDemoOne(obj);
            obj = 3.5;
            PatternMatchingDemoOne(obj);
            obj = 8;
            PatternMatchingDemoOne(obj);
        }

        public static void PatternMatchingDemoTwo()
        {
            object obj = 4;
            PatternMatchingDemoTwo(obj);
            obj = "Christian";
            PatternMatchingDemoTwo(obj);
            obj = null;
            PatternMatchingDemoTwo(obj);
            obj = "88.96";
            PatternMatchingDemoTwo(obj);
        }

        public static void PatternMatchingDemoThree()
        {
            object obj = 4;
            PatternMatchingDemoThree(obj);
            obj = "Christian";
            PatternMatchingDemoThree(obj);
            obj = null;
            PatternMatchingDemoThree(obj);
            obj = 3.5;
            PatternMatchingDemoThree(obj);
            obj = "Tony Jar";
            PatternMatchingDemoThree(obj);
            obj = 8;
            PatternMatchingDemoThree(obj);
            obj = "88.96";
            PatternMatchingDemoThree(obj);
        }

        public static void PatternMatchingDemoFour()
        {
            Shape sp = new Shape();
            PatternMatchingDemoFour(sp);
            sp = new Rectangle(5, 8);
            PatternMatchingDemoFour(sp);
            sp = null;
            try
            {
                PatternMatchingDemoFour(sp);
            }
            catch (Exception ex)
            {
                WriteLine(ex.Message.Replace('\r', ' ').Replace('\n', ' '));
            }
            sp = new Circle(12.5);
            PatternMatchingDemoFour(sp);
            sp = new Rectangle(7.5, 7.5);
            PatternMatchingDemoFour(sp);
        }
    }

    public class Shape { }

    public class Circle : Shape
    {
        public Circle() { }

        public Circle(double radius)
        {
            Radius = radius;
        }

        public double Radius { get; set; } = 1;
    }

    public class Rectangle : Shape
    {
        public Rectangle() { }

        public Rectangle(double length, double height)
        {
            Length = length;
            Height = height;
        }

        public double Length { get; set; }

        public double Height { get; set; }
    }
}
