﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;

namespace CSharpSevenFeatures
{
    /// <summary>
    /// 弃元：一种在应用程序代码中人为取消使用的临时虚拟变量
    /// 通常，在进行元组解构或使用 out 参数调用方法时，必须定义一个其值无关紧要且你不打算使用的变量，为处理此情况，C# 增添了对弃元的支持 
    /// 弃元是一个名为 _（下划线字符）的只写变量，可向单个变量赋予要放弃的所有值
    /// 弃元类似于未赋值的变量，它们没有值，编译器不为弃元变量分配存储空间，所以弃元可减少内存分配
    /// 在以下方案中支持弃元：
    /// 1）在对元组或用户定义的类型进行解构时
    /// 2）在使用 out 参数调用方法时
    /// 3）在使用 is 和 switch 语句匹配操作的模式中
    /// 4）在要将某赋值的值显式标识为弃元时用作独立标识符（独立弃元），可使用独立弃元来指示要忽略的任何变量
    /// </summary>
    public static class Discards
    {
        public static void DiscardsDemoOne()
        {
            var (_, _, _, pop1, _, pop2) = QueryCityDataForYears("New York City", 1960, 2010);
            WriteLine($"Population change, 1960 to 2010: {pop2 - pop1:N0}");

            (_, _, _, int pop3, _, var pop4) = QueryCityDataForYears("New York City", 1960, 2010);
            WriteLine($"Population change, 1960 to 2010: {pop3 - pop4:N0}");
        }

        public static void DiscardsDemoTwo()
        {
            Human human = new Human("John", "Quincy", "Adams", "Boston", "MA");

            var (fName1, _, city1, _) = human;
            WriteLine($"Hello {fName1} of {city1}!");

            (var fName2, _, string lName1) = human;
            WriteLine($"Hello {fName2} {lName1}!");

            (var fName3, _) = human;
            WriteLine($"Hello {fName3}!");

            var (fName, lName, city, status) = human;
            WriteLine($"Hello {fName} of {city}, {status}!");
        }

        public static void DiscardsDemoThree()
        {
            string[] dateStrings = {"05/01/2018 14:57:32.8", "2018-05-01 14:57:32.8",
                              "2018-05-01T14:57:32.8375298-04:00", "5/01/2018",
                              "5/01/2018 14:57:32.80 -07:00",
                              "1 May 2018 2:57:32.8 PM", "16-05-2018 1:00:32 PM",
                              "Fri, 15 May 2018 20:10:57 GMT" };
            foreach (string dateString in dateStrings)
            {
                if (DateTime.TryParse(dateString, out _))
                    WriteLine($"'{dateString}': valid");
                else
                    WriteLine($"'{dateString}': invalid");
            }

            GetCoordinates(out var cx, out double _);
            WriteLine($"Coord X: {cx}");

            GetCoordinates(out var cpx, out var _);
            WriteLine($"Coord X: {cpx}");

            GetCoordinates(out var ctx, out _);
            WriteLine($"Coord X: {ctx}");
        }

        public static void DiscardsDemoFour()
        {
            object[] objects = { CultureInfo.CurrentCulture,
                           CultureInfo.CurrentCulture.DateTimeFormat,
                           CultureInfo.CurrentCulture.NumberFormat,
                           new ArgumentException(), null };
            foreach (var obj in objects)
            {
                ProvidesFormatInfo(obj);
            }
        }

        public static void DiscardsDemoFive()
        {
            object[] objects = { CultureInfo.CurrentCulture,
                           CultureInfo.CurrentCulture.DateTimeFormat,
                           CultureInfo.CurrentCulture.NumberFormat,
                           new ArgumentException(), null };
            foreach (var obj in objects)
            {
                ProvidesFormatMsg(obj);
            }
        }

        public static void DiscardsDemoSix()
        {
            ExecuteAsyncMethods().GetAwaiter().GetResult();
        }

        public static void DiscardsDemoSeven()
        {
            ShowValue(4);
        }

        private static (string, double, int, int, int, int) QueryCityDataForYears(string name, int year1, int year2)
        {
            int population1 = 0, population2 = 0;
            double area = 0;

            if (name == "New York City")
            {
                area = 468.48;
                if (year1 == 1960)
                {
                    population1 = 7781984;
                }
                if (year2 == 2010)
                {
                    population2 = 8175133;
                }
                return (name, area, year1, population1, year2, population2);
            }

            return ("", 0, 0, 0, 0, 0);
        }

        private static void GetCoordinates(out double cx, out double cy)
        {
            cx = 8;
            cy = 9;
        }

        private static void ProvidesFormatInfo(object obj)
        {
            if (obj is IFormatProvider fmt)
            {
                WriteLine($"{fmt} object");
            }
            else if (obj is null)
            {
                Write("A null object reference: ");
                WriteLine("Its use could result in a NullReferenceException");
            }
            else if (obj is object _)
            {
                WriteLine("Some object type without format information");
            }
        }

        private static void ProvidesFormatMsg(object obj)
        {
            switch (obj)
            {
                case IFormatProvider fmt:
                    WriteLine($"{fmt} object");
                    break;
                case null:
                    Write("A null object reference: ");
                    WriteLine("Its use could result in a NullReferenceException");
                    break;
                case object _:
                    WriteLine("Some object type without format information");
                    break;
            }
        }

        private static async Task ExecuteAsyncMethods()
        {
            WriteLine("About to launch a task...");
            _ = Task.Run(() => {
                var iterations = 0;
                for (int ctr = 0; ctr < 4; ctr++)
                {
                    iterations++;
                }
                WriteLine("Completed looping operation...");
            });
            await Task.Delay(1500);
            WriteLine("Exiting after 5 second delay");
        }

        private static void ShowValue(int _)
        {
            WriteLine(_);
            byte[] arr = { 0, 0, 1, 2 };
            _ = BitConverter.ToInt32(arr, 0);
            int newValue;
            //! _ = Int32.TryParse("123", out newValue); // 转型错误
            //! var _ = "123"; // 作用域冲突
            WriteLine(_);
        }
    }

    public class Human
    {
        public string FirstName { get; set; }
        public string MiddleName { get; set; }
        public string LastName { get; set; }
        public string City { get; set; }
        public string State { get; set; }

        public Human(string fname, string mname, string lname,
                      string cityName, string stateName)
        {
            FirstName = fname;
            MiddleName = mname;
            LastName = lname;
            City = cityName;
            State = stateName;
        }

        // Return the first and last name.
        public void Deconstruct(out string fname, out string lname)
        {
            fname = FirstName;
            lname = LastName;
        }

        public void Deconstruct(out string fname, out string mname, out string lname)
        {
            fname = FirstName;
            mname = MiddleName;
            lname = LastName;
        }

        public void Deconstruct(out string fname, out string lname,
                                out string city, out string state)
        {
            fname = FirstName;
            lname = LastName;
            city = City;
            state = State;
        }
    }
}
