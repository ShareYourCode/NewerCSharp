﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;

namespace CSharpSevenFeatures
{
    /// <summary>
    /// 表达式中抛出异常
    /// </summary>
    public static class ThrowExpressions
    {
        public static void ThrowExpressionsDemoOne()
        {
            Staff staff = new Staff("Edmond Chou");
            WriteLine(staff.GetFirstName());
            try
            {
                staff = new Staff(null);
            }
            catch (Exception ex)
            {
                WriteLine(ex.Message);
            }
            staff = new Staff(String.Empty);
            try
            {
                WriteLine(staff.GetFirstName());
            }
            catch (Exception ex)
            {
                WriteLine(ex.Message);
            }
            try
            {
                WriteLine(staff.GetLastName());
            }
            catch (Exception ex)
            {
                WriteLine(ex.Message);
            }
        }
    }

    public class Staff
    {
        public string Name { get; }
        public Staff(string name) => Name = name ?? throw new ArgumentNullException(name);

        public string GetFirstName()
        {
            var parts = Name.Split(new string[] { " " }, StringSplitOptions.RemoveEmptyEntries);
            return (parts.Length > 0) ? parts[0] : throw new InvalidOperationException("No name!");
        }

        public string GetLastName() => throw new NotImplementedException();
    }
}
